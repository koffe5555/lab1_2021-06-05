﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Lab1_Kristoffer
{
    class Program
    {
        static void Main(string[] args)
        {
            //Random Array
            Random rnd = new Random();
            Random randNum = new Random();
            int number = rnd.Next(0,200);
            int[] myArray = new int[30];

            for (int i = 0; i < myArray.Length; i++)
            {
                myArray[i] = randNum.Next(0, 200);  
            }
            
            //Uppgift 1
            Console.WriteLine("Uppgift 1: \n");
            ArrayCounter(myArray, number);
            Console.WriteLine("-----------------------------------------------------------------");

            //Uppgift 2A - Brute Force
            Console.WriteLine("Uppgift 2 Bruteforce: \n");
            BruteForce(myArray);
            Console.WriteLine("-----------------------------------------------------------------");

            //Uppgift 2B - Algorithms
            Console.WriteLine("Uppgift 2 Algorithem: \n");
            ArrayDifference(myArray);
            Console.WriteLine("-----------------------------------------------------------------"); 

            //Uppgift 3A
            Console.WriteLine("Uppgift 3A 'slower': \n");
            Console.WriteLine(string.Join(" ",myArray));
            //ReverseSlower(myArray);
            Console.WriteLine("-----------------------------------------------------------------");
            
            //Uppgift 3B
            Console.WriteLine("Uppgift 3B 'faster': \n");
            ReverseFaster(myArray);
            Console.WriteLine("-----------------------------------------------------------------");  
        
        }

        //Uppgift 3A
        private static void ReverseSlower(int[] myArray)
        {
            DateTime startTime = DateTime.Now;
            StringBuilder csv = new StringBuilder();

            int i = 1;
            while(i < myArray.Length)
            {
                int nextVal = myArray[i];
                int j = i;
                while(j > 0)
                {
                    myArray[j] = myArray[j - 1];
                    j--;
                }
                myArray[0] = nextVal;
                i++;
            }
            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;
            Console.WriteLine("The reverse Array: "+string.Join(" ",myArray));
            Console.WriteLine("Time: "+elapsed.ToString().Substring(7));

            int arrLenght = myArray.Length;
            string n = arrLenght.ToString();
            string csvElapsed = elapsed.ToString();
            var csvText = String.Format("{0};{1};",csvElapsed.Substring(7),n);
            csv.Append(csvText);

            string newFileName = "resultsuppgift3_a.csv";
            if (!File.Exists(newFileName))
            {
                string clientheader = ("Time" + "," + "Count" + Environment.NewLine);
                File.WriteAllText(newFileName, clientheader);
            }
            File.AppendAllText(newFileName, csv.ToString() + Environment.NewLine);

        }

        //Uppgift 3B
        private static void ReverseFaster(int[] myArray)
        {
            DateTime startTime = DateTime.Now;
            StringBuilder csv = new StringBuilder();

            int Len = myArray.Length / 2; // 1 operation

            for(int i = 0; i <= Len; i++) //1 + n 
            {
                int holder = myArray[i];
                myArray[i] = myArray[myArray.Length - i -1];
                myArray[myArray.Length - i - 1] = holder;
                //myArray[Length -1 - i] = myArray[i];
                //Console.WriteLine(myArray[i].ToString());
            }

            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;

            Console.WriteLine("The array reversed: "+string.Join(" ",myArray)+"\n"+"Time: "+elapsed.ToString().Substring(7));

            int arrLenght = myArray.Length;
            string n = arrLenght.ToString();
            string csvElapsed = elapsed.ToString();
            var csvText = String.Format("{0};{1};",csvElapsed.Substring(7),n);
            csv.Append(csvText);

            string newFileName = "resultsuppgift3.csv";
            if (!File.Exists(newFileName))
            {
                string clientheader = ("Time" + "," + "Count" + Environment.NewLine);
                File.WriteAllText(newFileName, clientheader);
            }
            File.AppendAllText(newFileName, csv.ToString() + Environment.NewLine);
        }

        //Uppgift 1
        private static void ArrayCounter(int[] myArray, int number)
        {
            DateTime startTime = DateTime.Now;
            StringBuilder csv = new StringBuilder();
            
            int count = 0; // 1 operation
            foreach(var item in myArray) //1 operation som körs n gånger
            {
                Console.WriteLine("Nummer i arrayen: "+item);
                if(item == number) // 1 operation som körs n gånger
                {
                    count += 1; // 1 operation som körs n gånger
                }
            }
            //T(n) = 4 operationer och 3 n = 4+3n = O(n)  
            Console.WriteLine("Talet: "+number+" Förekommer: "+count+" gånger"); 
            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;
            
            Console.WriteLine("Time: "+elapsed.ToString().Substring(7));


            //To csv        
            string newFileName = "results.csv";
            string csvCount = count.ToString();
            string csvElapsed = elapsed.ToString();
            var csvText = String.Format("{0};{1};",csvElapsed.Substring(7),csvCount);
            csv.Append(csvText);
            if(!File.Exists(newFileName))
            {
                string clientheader = ("Time" + "," + "Count"+Environment.NewLine);
                File.WriteAllText(newFileName, clientheader);
            }
            File.AppendAllText(newFileName, csv.ToString() + Environment.NewLine);
        }

        //Uppgift 2A
        private static int BruteForce(int[] myArray)
        {
            DateTime startTime = DateTime.Now;
            int bigNumA = 0;
            foreach(int i in myArray) // Denna yttre loop körs n gånger
            {
                foreach(int j in myArray) // Denna inre loop körs n gånger
                {
                    int newNum = i - j;
                    if(newNum > bigNumA)
                    {
                        bigNumA = newNum; //Elementär operator (*) kommer köras n x n gånger så n^2
                    }
                }
            }
            //T(n) = n^2 = O(n^2)

            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;
            StringBuilder csv = new StringBuilder();
            Console.WriteLine("Time: "+elapsed.ToString().Substring(7)+"\n"+"Result: "+bigNumA+"\n");

            string newFileName = "results_uppgit_2.csv";
            string csvCount = bigNumA.ToString();
            string csvElapsed = elapsed.ToString();
            var csvText = String.Format("{0};{1};",csvElapsed.Substring(7),csvCount);
            csv.Append(csvText);
            if(!File.Exists(newFileName))
            {
                string clientheader = ("Time" + "," + "Count"+Environment.NewLine);
                File.WriteAllText(newFileName, clientheader);
            }
            File.AppendAllText(newFileName, csv.ToString() + Environment.NewLine);

            return bigNumA;
        }

        //Uppgift 2B
        private static int ArrayDifference(int[] myArray)
        {
            DateTime startTime = DateTime.Now;
            int small_num = 0; // 1 operation
            int biggest_num = 0; // 1 operation

            if (myArray.Length > 0) // Körs n gånger 1 operation
            {
                small_num = biggest_num = myArray[0]; //2 operationer som körs n - 1 gånger
            } 

            for (int i = 1; i < myArray.Length; i++) // 1 + n +(n-1) = 2n
            {
                small_num = Math.Min(small_num, myArray[i]); // 1 operation som körs (n-1) gånger
                biggest_num = Math.Max(biggest_num, myArray[i]); // 1 operation som körs (n-1) gånger 
                //2n-2
            }

            // T(n) = 1+1+1+n+2+n+2n+2n-2 = 6n-3 = O(n) 

            int result = biggest_num - small_num;
            DateTime stopTime = DateTime.Now;
            TimeSpan elapsed = stopTime - startTime;
            Console.WriteLine("Time: "+elapsed.ToString().Substring(7)+"\n"+"Result: "+result);

            StringBuilder csv = new StringBuilder();
            string newFileName = "results_uppgit_2_algo.csv";
            string csvCount = result.ToString();
            string csvElapsed = elapsed.ToString();
            var csvText = String.Format("{0};{1};",csvElapsed.Substring(7),csvCount);
            csv.Append(csvText);
            if(!File.Exists(newFileName))
            {
                string clientheader = ("Time" + "," + "Count"+Environment.NewLine);
                File.WriteAllText(newFileName, clientheader);
            }
            File.AppendAllText(newFileName, csv.ToString() + Environment.NewLine);            
            return result; 
        }
    }
}
